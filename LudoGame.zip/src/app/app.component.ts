import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  isDisabled: boolean = false;
  plyerOne: string = 'Akash';
  plyerTwo: string = 'Sanjay';
  dice: number = 1;
  plrOneGlobalScore: number = 0;
  plrOneCurrntScore: number = 0;
  plrTwoGlobalScore: number = 0;
  plrTwoCurrntScore: number = 0;
  activePlr1 = true;
  message:boolean = false;
  finalScore: any;

 conditionFn(){
  if (this.finalScore > 0) {
    this.buttonRoll();
  } else {
    alert('Please set The Target Score');
    return false;
  }
 }
  buttonRoll(){
    this.dice = Math.floor(Math.random() * 6 ) + 1 ;
    /* Check the Active Plyer*/ 
    if(this.activePlr1){
        if(this.dice != 1){
          this.plrOneCurrntScore = this.plrOneCurrntScore + this.dice;
        }
        else{
          this.plrOneCurrntScore = 0;
          this.activePlr1 = false;
        }
    }
    else{
        if(this.dice != 1){
          this.plrTwoCurrntScore = this.plrTwoCurrntScore + this.dice;
        }
        else{
          this.plrTwoCurrntScore = 0;
          this.activePlr1 = true;
        }
    }

    if( (this.plrOneGlobalScore + this.plrOneCurrntScore) > this.finalScore){
      this.plyerOne = 'Winner';
      this.isDisabled = true;
      this.message = true;
      this.plrOneGlobalScore = this.plrOneCurrntScore + this.plrOneGlobalScore;
    }else if (this.plrTwoGlobalScore + this.plrTwoCurrntScore > this.finalScore){
      this.plyerTwo = 'Winner';
      this.isDisabled = true;
      this.message = true;
      this.plrTwoGlobalScore = this.plrTwoCurrntScore + this.plrTwoGlobalScore;
    }
  }

  hold(){
    if (this.activePlr1) {
        this.plrOneGlobalScore = this.plrOneCurrntScore + this.plrOneGlobalScore;
        this.activePlr1 = false;
        this.setCurrentScoreZero()
    } else {
        this.plrTwoGlobalScore = this.plrTwoCurrntScore + this.plrTwoGlobalScore;
        this.activePlr1 = true;
        this.setCurrentScoreZero()
    }
  }

  setCurrentScoreZero(){
    this.plrOneCurrntScore = 0;
    this.plrTwoCurrntScore = 0
  }

  reset(){
    this.plyerOne = 'Akash';
    this.plyerTwo = 'Sanjay';
    this.dice = 1;
    this.plrOneGlobalScore = 0;
    this.plrOneCurrntScore = 0;
    this.plrTwoGlobalScore = 0;
    this.plrTwoCurrntScore = 0;
    this.activePlr1 = true;
    this.message = false;
    this.isDisabled = false;
  }
}

//*Game Rules 

//- The game has 2 players, playing in rounds
//- In each turn, a player rolls a dice as many times as he wishes. Each result get added to his ROUND score.
//- BUT, if the player rolls a 1, all his ROUND score gets lost. After that, it's the next player's turn.
//- The player can choose to 'Hold', which means that his ROUND score gets added to his GLOBAL score. After that, it's the next player's turn.
//- The first player to reach 100 points on GLOBAL score wins the game.

